No XML payload fixture.
